const mongoose=require("mongoose");
const PatientSchema=mongoose.Schema({
    FirstName:{
        type:String,
        required:true},
        LastName:{
            type:String,
            required:true
        },
        Gender:{
            type:String,
            required:true
        },
        Age:{
            type:Number,
            required:true
        },


});
const Student=mongoose.model("StudData",StudentSchema);
module.exports=Student;