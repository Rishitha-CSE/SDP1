const express=require("express");
const mongoose=require("mongoose");
const Student = require("./models/Student");
const StudentModel=require("./models/Student");
const app=express();
app.use(express.json());
mongoose.connect("mongodb+srv://admin123admin123:admin123@cluster0.pmu3npm.mongodb.net/HWS?retryWrites=true&w=majority",
{useNewUrlParser: true, },()=>console.log("Connected to DB"));

app.post("/newstud",async(req,res)=>{
    const FirstName=req.body.FirstName;
    const LastName=req.body.LastName;
    const Gender=req.body.Gender;
    const Age=req.body.Age;
    const student=new StudentModel({Firstname:FirstName,LastName:LastName,Gender:Gender,Age:Age});
    try{
    await student.save();
    res.send("Inserted Values");}

catch(err){
    console.log(err);
}});
app.get("/display",async(req,res)=>{
    StudentModel.find({},(err,result)=>{
        if(err){
            res.send(err);
        }
        res.json(result);
    });
});
app.put("/upstud",async(req,res)=>{
    const Firstname=req.body.FirstName;
    const id=req.body.id;
    
    try{
    await StudentModel.findById(id,(err,upStudent)=>{
        upStudent.name=Firstname;
        upStudent.save();
        res.json(StudentModel);
    });
    }

catch(err){
    console.log(err);
}});
app.delete("/delstud/:id",async(req,res)=>{
    const id=req.params.id;
    await StudentModel.findByIdAndRemove(id);
});
    app.listen(3001,()=>console.log("Server Ready."))